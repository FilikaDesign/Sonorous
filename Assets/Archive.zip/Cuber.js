#pragma strict




private var wall 		: GameObject;
private var floor 		: GameObject;

private var mouseScreen : Vector3 = new Vector3(0,0,0);
private var mouseWorld 	: Vector3 = new Vector3(0,0,0);
private var offSet 		: Vector3 = new Vector3(0,0,0);
	

private var woodThickness : float = 1;


function Start () {
	
	//camera positioning
	this.transform.position = Vector3(90,150,-250);
	this.transform.Rotate(15,-5,0);
	
	// Make a game object
	
	var lightGameObject : GameObject = new GameObject("The Light");
	
	// Add the light component
	lightGameObject.AddComponent(Light);
	// Set color and position
	lightGameObject.light.color = Color.white;
	lightGameObject.light.type = LightType.Directional;
	lightGameObject.light.intensity = 0.4;
	// Set the position (or any transform property) after
	// adding the light component.
	lightGameObject.transform.position = Vector3(0, 500, 0);
	lightGameObject.transform.Rotate(40, 5, 200);
	
	//point light
	var pointLightGameObject : GameObject = new GameObject("The Point One");
	
	// Add the light component
	pointLightGameObject.AddComponent(Light);
	// Set color and position
	pointLightGameObject.light.color = Color.white;
	pointLightGameObject.light.type = LightType.Point;
	pointLightGameObject.light.intensity = 1;
	pointLightGameObject.light.range = 130;
	// Set the position (or any transform property) after
	// adding the light component.
	pointLightGameObject.transform.position = Vector3(60, 140, -31);
	pointLightGameObject.transform.Rotate(40, 5, 200);
	
	
	//create Background Wall and Floor
	wall = GameObject.CreatePrimitive(PrimitiveType.Cube);
	wall.transform.position = Vector3(0,150,30);
	wall.transform.localScale = Vector3(800,2,300);
	wall.transform.Rotate(90,0,0);
	wall.renderer.material.mainTexture = Resources.Load("wall", Texture2D);
	wall.renderer.material.mainTextureScale = Vector2 (11,11);
	
	//floor
	floor = GameObject.CreatePrimitive(PrimitiveType.Cube);
	floor.transform.position = Vector3(0,0,-120);
	floor.transform.localScale = Vector3(800,2,300);
	floor.transform.Rotate(0,0,0);
	floor.renderer.material.mainTexture = Resources.Load("wooden-floor-texture", Texture2D);
	floor.renderer.material.mainTextureScale = Vector2 (11,11);

	
	//create Texture Data
	//create Elements
	var myStuffTex:Hashtable = {"Front":"H3375_ST22",
                        "FrontUp":"200s",
                        "FrontDown":"200s",
                        "Back":"H3375_ST22",
                        "Left":"H3375_ST22",
                        "Right":"H3375_ST22",
                        "Bottom":"H3375_ST22",
                        "Top":"200s",
                        "Hole":1
                        };
                        
	//create Elements
	
	var eleman : GameObject = new GameObject("Kutu");
	eleman.AddComponent("Element");
	
	var other : Element = eleman.GetComponent("Element");
	other.moveMe = 4;
	other.bWidth = 300;
	other.texture = myStuffTex;
	
	eleman.AddComponent(Rigidbody);
	eleman.rigidbody.isKinematic = true;
	
	///////
	
	var eleman2 : GameObject = new GameObject("Kutu");
	eleman2.AddComponent("Element");
	
	var other2 : Element = eleman.GetComponent("Element");
	other2.moveMe = 4;
	other2.bWidth = 30;
	other2.texture = myStuffTex;
	
	eleman2.AddComponent(Rigidbody);
	eleman2.rigidbody.isKinematic = true;
	
	
	
	/*
	var myStuff : Element = new Element(130,40,50,2,1);
	myStuff.Place(97,8);
	 
	var myStuff2 : Element = new Element(65,40,50,1,0);
	myStuff2.Place(0,8);
	 
	var myBase : Base = new Base(195,8,46);
	myBase.Place(65,0);
	
	*/
	
}

function Update () {
	var mainCamera = Camera.main;
	var hit : RaycastHit;

	if (Input.GetMouseButtonDown (0)){
	
		if( Physics.Raycast(mainCamera.ScreenPointToRay(Input.mousePosition),  hit ) ) {
		
		
			
			mouseScreen = Vector3(Input.mousePosition.x,Input.mousePosition.y,-1 * mainCamera.transform.position.z);
			
			mouseWorld = mainCamera.ScreenToWorldPoint(mouseScreen);
			
			offSet = mouseWorld-hit.transform.position;		
		
		    
		}
			
	
	}
	
	if (Input.GetMouseButton (0)){
	
		if( Physics.Raycast(mainCamera.ScreenPointToRay(Input.mousePosition),  hit ) ) {
			
			mouseScreen = Vector3(Input.mousePosition.x,Input.mousePosition.y,-1 * mainCamera.transform.position.z);
			
			mouseWorld = mainCamera.ScreenToWorldPoint(mouseScreen);
			
			
				
			if(hit.rigidbody){
			
				var oLayer1 : 	GameObject = hit.collider.gameObject;
	 	 		var oLayer2	:	GameObject = oLayer1.transform.parent.gameObject;
	 	 		var oLayer3	:	GameObject = oLayer2.transform.parent.gameObject; 	 		
	 	 		
	 	 		var variableScript : Element;
	 	 		variableScript = oLayer3.GetComponent("Element");
	 	 		
	 	 		Debug.Log(variableScript.moveMe);
	 	 
		    	hit.transform.position.x = mouseWorld.x - offSet.x;
				hit.transform.position.y = mouseWorld.y - offSet.y;
				hit.transform.position.z = 0;	    	
	    	}
	   
		}
	}
	
	 
}
