#pragma strict

var elementContainer: GameObject;
var cubeFront 		: GameObject;
var cubeFrontUp		: GameObject;
var cubeFrontDown	: GameObject;
var cubeBack 		: GameObject;
var cubeLeft 		: GameObject;
var cubeRight 		: GameObject;
var cubeBottom 		: GameObject;
var cubeTop 		: GameObject;
var cubeHole 		: GameObject;
var woodThickness 	: float = 1;
var hole			: int;
var xPos				: int = 0;
var yPos				: int = 0;
var moveMe : int = 1;
var bWidth : int = 130;
var texture:Hashtable = {};

function Start (){
    	
    		 
    		var bHeight : int = 40;
    		var bDepth : int = 50;
    		var nFrontface : int = 1;
    		var hole : int = 1;
    		
    		
    		elementContainer = new GameObject("Element Container");
    		
    		elementContainer.transform.parent = this.transform;
    		

			if(nFrontface == 1){
	
			//Front
		    cubeFront  = GameObject.CreatePrimitive(PrimitiveType.Cube);
		    cubeFront.transform.localScale = Vector3(bWidth,bHeight,woodThickness);
			cubeFront.transform.localPosition = Vector3(0,bHeight * 0.5, -1 * bDepth * 0.5 + woodThickness*0.5);
			cubeFront.renderer.material.mainTexture = Resources.Load(texture["Front"], Texture2D);
			cubeFront.transform.parent = elementContainer.transform;
			
			
			}else if(nFrontface == 2){
			
			
			//FrontUp
		    cubeFrontUp  = GameObject.CreatePrimitive(PrimitiveType.Cube);
		    cubeFrontUp.transform.localScale = Vector3(bWidth,bHeight*0.5-woodThickness*0.2,woodThickness);
			cubeFrontUp.transform.localPosition = Vector3(0,bHeight * 0.75, -1 * bDepth * 0.5 + woodThickness*0.5);
			cubeFrontUp.renderer.material.mainTexture = Resources.Load(texture["FrontUp"], Texture2D);
			cubeFrontUp.transform.parent = elementContainer.transform;
			//FrontDown
			cubeFrontDown  = GameObject.CreatePrimitive(PrimitiveType.Cube);
		    cubeFrontDown.transform.localScale = Vector3(bWidth,bHeight*0.5-woodThickness*0.2,woodThickness);
			cubeFrontDown.transform.localPosition = Vector3(0,bHeight * 0.25, -1 * bDepth * 0.5 + woodThickness*0.5);
			cubeFrontDown.renderer.material.mainTexture = Resources.Load(texture["FrontDown"], Texture2D);
			cubeFrontDown.transform.parent = elementContainer.transform;
			
			}
			
			//Back
		    cubeBack  = GameObject.CreatePrimitive(PrimitiveType.Cube);
		    cubeBack.transform.localScale = Vector3(bWidth,bHeight,woodThickness);
			cubeBack.transform.localPosition = Vector3(0,bHeight * 0.5, bDepth * 0.5 - woodThickness*0.5);
			cubeBack.renderer.material.mainTexture = Resources.Load(texture["Back"], Texture2D);
			cubeBack.transform.parent = elementContainer.transform;
			
			//Left
		    cubeLeft  = GameObject.CreatePrimitive(PrimitiveType.Cube);
		    cubeLeft.transform.localScale = Vector3(woodThickness,bHeight,bDepth);
			cubeLeft.transform.localPosition = Vector3(-1 * bWidth * 0.5 + woodThickness*0.5,bHeight * 0.5, 0);
			cubeLeft.renderer.material.mainTexture = Resources.Load(texture["Left"], Texture2D);
			cubeLeft.transform.parent = elementContainer.transform;
			
			//Right
		    cubeRight  = GameObject.CreatePrimitive(PrimitiveType.Cube);
		    cubeRight.transform.localScale = Vector3(woodThickness,bHeight,bDepth);
			cubeRight.transform.localPosition = Vector3(bWidth * 0.5 - woodThickness*0.5,bHeight * 0.5, 0);
			cubeRight.renderer.material.mainTexture = Resources.Load(texture["Right"], Texture2D);
			cubeRight.transform.parent = elementContainer.transform;
			
			//Bottom
		    cubeBottom  = GameObject.CreatePrimitive(PrimitiveType.Cube);
		    cubeBottom.transform.localScale = Vector3(bWidth,woodThickness,bDepth);
			cubeBottom.transform.localPosition = Vector3(0,woodThickness*0.5, 0);
			cubeBottom.renderer.material.mainTexture = Resources.Load(texture["Bottom"], Texture2D);
			cubeBottom.transform.parent = elementContainer.transform;
			
			//Top
		    cubeTop  = GameObject.CreatePrimitive(PrimitiveType.Cube);
		    cubeTop.transform.localScale = Vector3(bWidth,woodThickness,bDepth);
			cubeTop.transform.localPosition = Vector3(0,bHeight, 0);
			cubeTop.renderer.material.mainTexture = Resources.Load(texture["Top"], Texture2D);
			//cubeTop.renderer.material.color = Color.gray;
			cubeTop.transform.parent = elementContainer.transform;
			
			
			if(hole == texture["Hole"]){
			//Hole
		    cubeHole  = GameObject.CreatePrimitive(PrimitiveType.Cube);
		    cubeHole.transform.localScale = Vector3(10,0,3);
			cubeHole.transform.localPosition = Vector3(0,bHeight+1, bDepth*0.5-1.8);
			cubeHole.renderer.material.color = Color.gray;
			cubeHole.transform.parent = elementContainer.transform;
			
			}
			
			
			
    	}
    	
    	
    	
    	function Place (_xPos : int, _yPos : int)
    	{
       		 	xPos = _xPos;
       	 		yPos = _yPos;
       	 		elementContainer.transform.localPosition = Vector3(xPos,yPos, 0);
       	 		
        
    	}
    	

    	function Update ()
    	{
    	
    	
        	
    	}
    	
